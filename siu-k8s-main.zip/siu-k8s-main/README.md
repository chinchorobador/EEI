# EEI en Kubernetes

Este repo contiene los archivos base para el despliegue del ecosistema siu en kubernetes.

## Despliegue en Kubernetes

Para info sobre el despliegue dirigirse a este [repo](https://gitlab.siu.edu.ar/devops/k8s-deployments).